def first_and_last_characters(pStr):
    return 'First character: ' + pStr[0]+ '\nLast character: '+ pStr[-1]