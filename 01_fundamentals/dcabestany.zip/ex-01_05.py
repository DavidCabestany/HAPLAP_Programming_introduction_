
degree_sign= u'\N{DEGREE SIGN}'

celsius = int(input("How many Celsius?"))

fahrenheit = celsius * (9/5) + 32

print(str(fahrenheit)+degree_sign, 'Fahrenheit')