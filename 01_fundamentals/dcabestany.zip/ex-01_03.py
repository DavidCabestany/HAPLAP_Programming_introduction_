num = int(input('Enter a number: '))
next_num = num + 1
print(next_num)
