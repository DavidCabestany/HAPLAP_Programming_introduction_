def is_positive(num):
    user_num = int(num)
    if user_num >= 0:
        return "The number entered is positive"
    else:
        return "The number entered is not positive"