def inhabitants(city):
    if city == 'Donostia':
        return 'Hello Donostiarra!'
    if city == 'Istanbul':
        return 'Hello Istanbulite!'
    elif city == 'Aberdeen':
        return 'Hello Aberdonian!'
    elif city == 'Sydney':
        return 'Hello Sydneyite!'
    else:
        return "I'm sorry, I don't know your town..."