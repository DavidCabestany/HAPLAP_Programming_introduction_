name = input("What's your name? ")

print('Your name is:', name)
