age = int(input("How old are you?"))

birth = 2021 - age

print(birth)
