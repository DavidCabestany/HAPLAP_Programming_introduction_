def password(user_pass):
    psw = 'kukuakEgitenDuKuku'
    if user_pass == psw:
        return 'Access allowed'
    else:
        return 'Access denied'