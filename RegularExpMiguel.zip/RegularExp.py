
import re

def set_of_characters(a :str):  #!!!!!!

    ret = False

    if re.match(r'(\w*)$', a) != None:
        ret = True

    return ret

def a_followed_by_zero_or_more_b(a :str):

    ret = False

    if re.match(r'ab*$', a) != None:
        ret = True

    return ret

def a_followed_by_one_or_more_b(a :str):
    
    if re.match(r'ab+$', a) != None:
        ret = True

    return ret

def a_followed_by_zero_or_one_b(a :str):

    ret = False

    if re.match(r'ab?$', a) != None:
        ret = True

    return ret

def a_followed_by_three_b(a :str):

    ret = False

    if re.match(r'ab{3}$', a) != None:
        ret = True

    return ret

def word_at_the_beginning(myString :str, wordToCheck :str):

    ret = False

    pattern = str(wordToCheck)
    cpat = re.compile(pattern)

    if cpat.match(myString) != None:
        ret = True

    return ret

def word_at_the_end(myString : str, wordToCheck :str):
    
    ret = False

    if re.search(wordToCheck+'$', myString) != None:
        ret = True

    return ret

def has_vowel(a :str):

    ret = False

    if re.search(r'[aeiou]+', a) != None:
        ret = True

    return ret

def is_integer(a :str):

    ret = False

    if re.match(r'\d+$', a) != None:
        ret = True

    return ret

def is_fraction(a: str):

    ret = False

    if re.match(r'-?\d+/[1-9][0-9]*$', a) != None:
        ret = True

    return ret

def numbers_in_a_string(a: str):

    out = re.findall(r'\d+', a)

    return out

def valid_date(a : str):

    ret = False

    if re.match(r'\d{4}-\d{2}-\d{2}$', a) != None:
        ret = True

    return ret

def normalize_whitespace(a: str):

    out = re.sub(r'\s' , r' ', a)

    return out

def remove_non_alphanumeric(a: str):

    out = re.sub(r'\W' , r'', a)

    return out

def valid_email(a: str):

    ret = False

    if re.match(r'\w+@(\w|\.)+\.(edu|com|ord|net)$', a) != None:
        ret = True

    return ret
