
from os import stat
import nltk

from nltk.book import *

def lexical_diversity_in_text(text):

    sorted(set(text))

    return len(text)/len(set(text))

def lexical_diversity_in_nine_texts():

    textNames = [text1, text2, text3, text4, text5, text6, text7, text8, text9]   #Compromise done because dynamic variable creation is not possible in Python

    #Temporary working variables used in the loop below
    greatestLexicalDiv = (text1, 0.0)
    lexDiv = 0.0
    
    #Loop through all texts stored in textNames
    for i in textNames:

        lexDiv = lexical_diversity_in_text(i)
        
        print(i, lexDiv)

        #Update tuple storing the textname with higher lexical diversity
        #if, along the loop, we find a higher one:
        if greatestLexicalDiv[1] < lexDiv:
            greatestLexicalDiv = (i, lexDiv)

    print("The text with the greatest lexical diversity is ", greatestLexicalDiv[0], ", with a value of ", greatestLexicalDiv[1])

    return

def thirty_most_frequent_nononstop_words_in_text(text):

    from nltk.corpus import stopwords
    import nltk.probability

    ret = []

    stops = set(stopwords.words('english'))
    punctuation_symbols = ['.', '."', ',',',"', ';',';"', ':',':"', '?','?"', '!','!"', '"', '-','-"', '--','--"', '\'','"\'', '/']

    text_cleaned = []
    for word in text:
        if word not in stops and word not in punctuation_symbols:
            text_cleaned.append(word)

    fdist = FreqDist(text_cleaned)
    ret = fdist.most_common(30)

    return ret

def thirty_most_frequent_words_in_nltk_book_package():

    textNames = [text1, text2, text3, text4, text5, text6, text7, text8, text9]   #Compromise done because dynamic variable creation is not possible in Python

    for text in textNames:
        print(text, thirty_most_frequent_nononstop_words_in_text(text))

    return

def wh_words_Romance_Brown_corpus():

    from nltk.corpus import brown
    import nltk.probability

    #Return dictionary, each key is a wh- word
    #and for each key we have the number of times
    #that word has appeared in the Brown corpus
    ret = {
            "what": 0,
            "when": 0,
            "where": 0,
            "who": 0,
            "why": 0
          }

    #Get words from Brown corpus under the category "romance"
    words = brown.words(categories='romance')

    fdist = nltk.FreqDist([w.lower() for w in words])

    #Loop through each wh- word in the return dictionary structure,
    #count its number of occurrences in the retrieved word corpus.
    #Also print it onscreen while on the process
    for word in ret:
        ret[word] = fdist[word]
        print(word + ":", ret[word])

    return ret

def tokenize_lemmatize_Gutenberg_text():

    from nltk.tokenize import word_tokenize
    from nltk.stem import WordNetLemmatizer
    from urllib import request

    url = "http://www.gutenberg.org/files/2554/2554-0.txt"
    response = request.urlopen(url)
    raw = response.read().decode('utf8')

    tokenized_text = word_tokenize(raw)

    wnl = WordNetLemmatizer()

    lemmatizedText = []

    for word in tokenized_text:
        lemmatizedText.append(wnl.lemmatize(word))
    
    return lemmatizedText

def percentage_of_text_taken_up_by_word(text, word):

    return (text.count(word) / len(text)) * 100

def two_news_html_cleaned_tokenized_nostopwords(word :str):

    from bs4 import BeautifulSoup
    from urllib import request
    from nltk.tokenize import word_tokenize
    from nltk.corpus import stopwords

    raw_text = [[], []]

    url = \
    [
        "https://www.heraldo.es/noticias/aragon/huesca/2021/12/08/el-tunel-de-bielsa-reabre-al-trafico-pero-siguen-las-restricciones-en-una-docena-de-carreteras-del-pirineo-1539010.html",
        "https://www.heraldo.es/noticias/aragon/2021/12/11/el-tsja-suspende-la-entrada-en-vigor-de-la-ampliacion-del-pasaporte-covid-en-la-hosteleria-y-otros-sectores-1539706.html"
    ]

    #Get stopwords for Spanish (articles are in Spanish)
    stops = set(stopwords.words('spanish'))

    #Loop through the two articles
    for i in range(len(url)):
        print("News article ", i+1, ":", url[i], "\n")
        html = (request.urlopen(url[i])).read().decode('utf8')

        soup = BeautifulSoup(html, "html.parser")

        #The raw text contains A LOT of JavaScript code, which we promptly get rid of:
        for script in soup(["script", "style"]):
            script.decompose()

        #Get raw text out of its HTML entourage
        raw = soup.get_text()

        #Tokenize obtained text and remove stopwords
        tokenized_text = word_tokenize(raw)
        for w in tokenized_text:
            if w not in stops:
                raw_text[i].append(w)

        #Taking the "words" list passed to this function, analyze the percentage taken
        #up by those word in this specific news article
        print(percentage_of_text_taken_up_by_word(raw_text[i], word), "% taken in this article by the word", word)

        print("-------------------------------------\n")

    return

two_news_html_cleaned_tokenized_nostopwords("contagios")